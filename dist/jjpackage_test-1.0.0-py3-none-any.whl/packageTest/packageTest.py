def test_package():
    print("This is package test")